# TODO: Finish this after getting sequential and base refactored and perfect
